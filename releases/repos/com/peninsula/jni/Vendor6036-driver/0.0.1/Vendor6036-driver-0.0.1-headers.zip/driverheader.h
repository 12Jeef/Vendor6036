#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void helloWorld();

#ifdef __cplusplus
}  // extern "C"
#endif
